/**
 * three-hero.js
 * ─────────────────────────────────────────────────────
 * Premium Three.js particle constellation system
 * for the hero section background.
 *
 * Requires: Three.js r128 loaded via CDN before this script.
 * Target:   <canvas id="hero-canvas"> inside .hero
 * ─────────────────────────────────────────────────────
 */
(function () {
  'use strict';

  /* ── Feature / preference guards ─────────────────── */
  var prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ── Constants ───────────────────────────────────── */
  var COLORS = {
    cyan:    0x00f9ff,
    magenta: 0xff00aa,
    purple:  0x9d4edd
  };
  var COLOR_ARRAY = [COLORS.cyan, COLORS.magenta, COLORS.purple];
  var CONNECTION_DISTANCE = 120;
  var CONNECTION_OPACITY  = 0.12;
  var MOUSE_INFLUENCE     = 80;
  var CAMERA_ORBIT_SPEED  = 0.00012;
  var PARTICLE_COUNT      = window.innerWidth < 768 ? 800 : 2000;
  var FIELD_RADIUS        = 420;

  /* ── DOM references ──────────────────────────────── */
  var canvas = document.getElementById('hero-canvas');
  if (!canvas) return;

  var heroSection = canvas.closest('.hero') || canvas.parentElement;

  /* ── Renderer ────────────────────────────────────── */
  var renderer = new THREE.WebGLRenderer({
    canvas: canvas,
    alpha: true,
    antialias: false,
    powerPreference: 'high-performance'
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  renderer.setClearColor(0x000000, 0);

  /* ── Scene ───────────────────────────────────────── */
  var scene = new THREE.Scene();

  /* Nebula fog */
  scene.fog = new THREE.FogExp2(0x0a0a0f, 0.0012);

  /* ── Camera ──────────────────────────────────────── */
  var camera = new THREE.PerspectiveCamera(60, 1, 1, 2000);
  camera.position.z = 500;

  /* ── Mouse tracking ──────────────────────────────── */
  var mouse = { x: 0, y: 0, active: false };

  function onMouseMove(e) {
    var rect = canvas.getBoundingClientRect();
    mouse.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouse.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;
    mouse.active = true;
  }

  function onMouseLeave() {
    mouse.active = false;
  }

  canvas.addEventListener('mousemove', onMouseMove, { passive: true });
  canvas.addEventListener('mouseleave', onMouseLeave, { passive: true });

  /* ── Build Particles ─────────────────────────────── */
  var positions  = new Float32Array(PARTICLE_COUNT * 3);
  var colors     = new Float32Array(PARTICLE_COUNT * 3);
  var sizes      = new Float32Array(PARTICLE_COUNT);
  var velocities = new Float32Array(PARTICLE_COUNT * 3);
  var phases     = new Float32Array(PARTICLE_COUNT); // for pulsing

  var tmpColor = new THREE.Color();

  for (var i = 0; i < PARTICLE_COUNT; i++) {
    /* Spherical distribution for constellation feel */
    var theta  = Math.random() * Math.PI * 2;
    var phi    = Math.acos(2 * Math.random() - 1);
    var radius = FIELD_RADIUS * (0.3 + Math.random() * 0.7);

    positions[i * 3]     = radius * Math.sin(phi) * Math.cos(theta);
    positions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
    positions[i * 3 + 2] = radius * Math.cos(phi);

    /* Random velocity for drift */
    velocities[i * 3]     = (Math.random() - 0.5) * 0.15;
    velocities[i * 3 + 1] = (Math.random() - 0.5) * 0.15;
    velocities[i * 3 + 2] = (Math.random() - 0.5) * 0.15;

    /* Random color from palette */
    tmpColor.set(COLOR_ARRAY[Math.floor(Math.random() * COLOR_ARRAY.length)]);
    colors[i * 3]     = tmpColor.r;
    colors[i * 3 + 1] = tmpColor.g;
    colors[i * 3 + 2] = tmpColor.b;

    /* Random sizes 0.5 – 2.5 */
    sizes[i] = 0.5 + Math.random() * 2.0;

    /* Random phase offset for pulsing */
    phases[i] = Math.random() * Math.PI * 2;
  }

  var particleGeometry = new THREE.BufferGeometry();
  particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  particleGeometry.setAttribute('color',    new THREE.BufferAttribute(colors, 3));
  particleGeometry.setAttribute('size',     new THREE.BufferAttribute(sizes, 1));

  /* Custom shader for glowing dots with per-particle size + pulsing */
  var particleMaterial = new THREE.ShaderMaterial({
    uniforms: {
      uTime:       { value: 0 },
      uPixelRatio: { value: renderer.getPixelRatio() }
    },
    vertexShader: [
      'uniform float uTime;',
      'uniform float uPixelRatio;',
      'attribute float size;',
      'varying vec3 vColor;',
      'varying float vOpacity;',
      'void main() {',
      '  vColor = color;',
      '  vec4 mvPos = modelViewMatrix * vec4(position, 1.0);',
      '  float pulse = 0.7 + 0.3 * sin(uTime * 1.2 + position.x * 0.05 + position.y * 0.03);',
      '  vOpacity = pulse;',
      '  gl_PointSize = size * uPixelRatio * pulse * (280.0 / -mvPos.z);',
      '  gl_Position = projectionMatrix * mvPos;',
      '}'
    ].join('\n'),
    fragmentShader: [
      'varying vec3 vColor;',
      'varying float vOpacity;',
      'void main() {',
      '  float d = length(gl_PointCoord - vec2(0.5));',
      '  if (d > 0.5) discard;',
      '  float glow = 1.0 - smoothstep(0.0, 0.5, d);',
      '  glow = pow(glow, 1.6);',
      '  gl_FragColor = vec4(vColor, glow * vOpacity * 0.9);',
      '}'
    ].join('\n'),
    vertexColors: true,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending
  });

  var particleSystem = new THREE.Points(particleGeometry, particleMaterial);
  scene.add(particleSystem);

  /* ── Connection Lines ────────────────────────────── */
  var MAX_LINES = 3000;
  var linePositions = new Float32Array(MAX_LINES * 6);
  var lineColors    = new Float32Array(MAX_LINES * 6);

  var lineGeometry = new THREE.BufferGeometry();
  lineGeometry.setAttribute('position', new THREE.BufferAttribute(linePositions, 3));
  lineGeometry.setAttribute('color',    new THREE.BufferAttribute(lineColors, 3));
  lineGeometry.setDrawRange(0, 0);

  var lineMaterial = new THREE.LineBasicMaterial({
    vertexColors: true,
    transparent: true,
    opacity: CONNECTION_OPACITY,
    blending: THREE.AdditiveBlending,
    depthWrite: false
  });

  var linesMesh = new THREE.LineSegments(lineGeometry, lineMaterial);
  scene.add(linesMesh);

  /* ── Nebula ambient light spheres (subtle glow) ──── */
  var nebulaGroup = new THREE.Group();
  scene.add(nebulaGroup);

  function createNebulaBlob(color, x, y, z, scale) {
    var geo = new THREE.SphereGeometry(1, 16, 16);
    var mat = new THREE.MeshBasicMaterial({
      color: color,
      transparent: true,
      opacity: 0.015,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });
    var mesh = new THREE.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    mesh.scale.setScalar(scale);
    nebulaGroup.add(mesh);
    return mesh;
  }

  createNebulaBlob(COLORS.cyan,    -150,  100, -200, 200);
  createNebulaBlob(COLORS.magenta,  180, -80,  -100, 250);
  createNebulaBlob(COLORS.purple,    50,  150, -300, 180);
  createNebulaBlob(COLORS.cyan,    -100, -200, -150, 220);

  /* ── Resize handler ──────────────────────────────── */
  function resize() {
    var w = heroSection.clientWidth;
    var h = heroSection.clientHeight;
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    renderer.setSize(w, h);
    particleMaterial.uniforms.uPixelRatio.value = renderer.getPixelRatio();
  }

  resize();
  window.addEventListener('resize', resize, { passive: true });

  /* ── Spatial hashing for connection lines ────────── */
  function buildConnections(posAttr) {
    var cellSize = CONNECTION_DISTANCE;
    var grid = {};
    var count = posAttr.count;
    var arr   = posAttr.array;

    /* Populate grid */
    for (var i = 0; i < count; i++) {
      var cx = Math.floor(arr[i * 3]     / cellSize);
      var cy = Math.floor(arr[i * 3 + 1] / cellSize);
      var cz = Math.floor(arr[i * 3 + 2] / cellSize);
      var key = cx + ',' + cy + ',' + cz;
      if (!grid[key]) grid[key] = [];
      grid[key].push(i);
    }

    var lineIdx = 0;
    var lPos = lineGeometry.attributes.position.array;
    var lCol = lineGeometry.attributes.color.array;
    var distSq = CONNECTION_DISTANCE * CONNECTION_DISTANCE;

    var keys = Object.keys(grid);
    for (var k = 0; k < keys.length; k++) {
      var cell = grid[keys[k]];
      var parts = keys[k].split(',');
      var gx = parseInt(parts[0], 10);
      var gy = parseInt(parts[1], 10);
      var gz = parseInt(parts[2], 10);

      /* Check this cell and neighbors */
      for (var dx = -1; dx <= 1; dx++) {
        for (var dy = -1; dy <= 1; dy++) {
          for (var dz = -1; dz <= 1; dz++) {
            var nKey = (gx + dx) + ',' + (gy + dy) + ',' + (gz + dz);
            var neighbor = grid[nKey];
            if (!neighbor) continue;

            for (var a = 0; a < cell.length; a++) {
              var idxA = cell[a];
              for (var b = 0; b < neighbor.length; b++) {
                var idxB = neighbor[b];
                if (idxA >= idxB) continue;
                if (lineIdx >= MAX_LINES) break;

                var ax = arr[idxA * 3],     ay = arr[idxA * 3 + 1], az = arr[idxA * 3 + 2];
                var bx = arr[idxB * 3],     by = arr[idxB * 3 + 1], bz = arr[idxB * 3 + 2];
                var d2 = (ax - bx) * (ax - bx) + (ay - by) * (ay - by) + (az - bz) * (az - bz);

                if (d2 < distSq) {
                  var off = lineIdx * 6;
                  lPos[off]     = ax; lPos[off + 1] = ay; lPos[off + 2] = az;
                  lPos[off + 3] = bx; lPos[off + 4] = by; lPos[off + 5] = bz;

                  /* Fade color by distance */
                  var fade = 1 - Math.sqrt(d2) / CONNECTION_DISTANCE;
                  var cr = colors[idxA * 3]     * fade;
                  var cg = colors[idxA * 3 + 1] * fade;
                  var cb = colors[idxA * 3 + 2] * fade;
                  lCol[off]     = cr; lCol[off + 1] = cg; lCol[off + 2] = cb;
                  lCol[off + 3] = cr; lCol[off + 4] = cg; lCol[off + 5] = cb;

                  lineIdx++;
                }
              }
              if (lineIdx >= MAX_LINES) break;
            }
            if (lineIdx >= MAX_LINES) break;
          }
          if (lineIdx >= MAX_LINES) break;
        }
        if (lineIdx >= MAX_LINES) break;
      }
      if (lineIdx >= MAX_LINES) break;
    }

    lineGeometry.setDrawRange(0, lineIdx * 2);
    lineGeometry.attributes.position.needsUpdate = true;
    lineGeometry.attributes.color.needsUpdate = true;
  }

  /* ── Animation loop ──────────────────────────────── */
  var clock = new THREE.Clock();
  var lineRebuildTimer = 0;
  var LINE_REBUILD_INTERVAL = 0.25; // rebuild lines every 250ms

  function animate() {
    requestAnimationFrame(animate);

    var elapsed = clock.getElapsedTime();
    var delta   = clock.getDelta();

    /* Update time uniform for pulsing */
    particleMaterial.uniforms.uTime.value = elapsed;

    /* Move particles */
    var posArr = particleGeometry.attributes.position.array;

    if (!prefersReducedMotion) {
      /* Unproject mouse to world space for interaction */
      var mouseWorld = new THREE.Vector3(mouse.x, mouse.y, 0.5);
      mouseWorld.unproject(camera);
      var dir = mouseWorld.sub(camera.position).normalize();
      var mouseTarget = camera.position.clone().add(dir.multiplyScalar(500));

      for (var i = 0; i < PARTICLE_COUNT; i++) {
        var ix = i * 3;
        var iy = ix + 1;
        var iz = ix + 2;

        /* Drift */
        posArr[ix] += velocities[ix];
        posArr[iy] += velocities[iy];
        posArr[iz] += velocities[iz];

        /* Boundary: soft pull back toward center */
        var dist = Math.sqrt(posArr[ix] * posArr[ix] + posArr[iy] * posArr[iy] + posArr[iz] * posArr[iz]);
        if (dist > FIELD_RADIUS) {
          var pull = (dist - FIELD_RADIUS) * 0.002;
          posArr[ix] -= (posArr[ix] / dist) * pull;
          posArr[iy] -= (posArr[iy] / dist) * pull;
          posArr[iz] -= (posArr[iz] / dist) * pull;
        }

        /* Mouse influence: gentle repel */
        if (mouse.active) {
          var mdx = posArr[ix] - mouseTarget.x;
          var mdy = posArr[iy] - mouseTarget.y;
          var mdist = Math.sqrt(mdx * mdx + mdy * mdy);
          if (mdist < MOUSE_INFLUENCE && mdist > 0.1) {
            var force = (1 - mdist / MOUSE_INFLUENCE) * 0.8;
            posArr[ix] += (mdx / mdist) * force;
            posArr[iy] += (mdy / mdist) * force;
          }
        }
      }

      particleGeometry.attributes.position.needsUpdate = true;

      /* Orbital camera rotation */
      var orbitAngle = elapsed * CAMERA_ORBIT_SPEED * 60;
      camera.position.x = Math.sin(orbitAngle) * 60;
      camera.position.y = Math.cos(orbitAngle * 0.7) * 30;
      camera.lookAt(0, 0, 0);

      /* Subtle nebula rotation */
      nebulaGroup.rotation.y = elapsed * 0.02;
      nebulaGroup.rotation.x = Math.sin(elapsed * 0.01) * 0.1;
    }

    /* Rebuild connection lines periodically */
    lineRebuildTimer += delta;
    if (lineRebuildTimer >= LINE_REBUILD_INTERVAL) {
      lineRebuildTimer = 0;
      buildConnections(particleGeometry.attributes.position);
    }

    renderer.render(scene, camera);
  }

  /* ── Initial build & start ───────────────────────── */
  buildConnections(particleGeometry.attributes.position);
  animate();

})();
