# Anti-Gravity Studio — Gig Portfolio

Premium media studio with 3 pillars: Weddings (Radha), Corporate (Veronica), Tours (Trail Curator).

## Quick Start (Local)

```bash
npm install
node scripts/setup.js   # creates .env + upload folders
npm start
```

Open http://localhost:3005  
Admin: http://localhost:3005/admin/login.html  
Password: `RD@Admin2026!` (change in .env)

## Deploy to Railway (free)

1. Push to GitHub
2. Go to railway.app → New Project → Deploy from GitHub
3. Add environment variables from `.env.example`
4. Deploy — Railway auto-detects Node.js

## Deploy to Render (free)

1. Push to GitHub
2. Go to render.com → New Web Service → Connect GitHub repo
3. Build: `npm install --omit=dev`
4. Start: `node server.js`
5. Add env vars from `.env.example`

## Deploy with Docker

```bash
docker build -t anti-gravity-studio .
docker run -p 3005:3005 --env-file .env anti-gravity-studio
```

## Environment Variables

| Key | Required | Description |
|-----|----------|-------------|
| `ADMIN_USER_PASSWORD` | ✅ | Admin panel password |
| `SESSION_SECRET` | ✅ | Random 64-char string |
| `CLOUDINARY_NAME/KEY/SECRET` | ❌ | Cloud image storage (local fallback if not set) |
| `GOOGLE_PLACES_API_KEY` | ❌ | Google Reviews widget |
| `GEMINI_API_KEY` | ❌ | AI content generation |

## Stack

- **Server**: Node.js + Express 5
- **Database**: sql.js (zero-native SQLite — works everywhere)
- **Media**: Cloudinary (optional) or local `/uploads/`
- **Frontend**: Vanilla HTML/CSS/JS + Three.js

## The 3 Pillars

| Pillar | Page | Services |
|--------|------|----------|
| 💍 Radha | `/pillar-radha.html` | Weddings, Sangeet, Heirloom Photography |
| 🎤 Veronica | `/pillar-veronica.html` | Corporate MC, Conferences, Events |
| 🧭 Trail Curator | `/pillar-tour.html` | Heritage Walks, Mountain Treks |
